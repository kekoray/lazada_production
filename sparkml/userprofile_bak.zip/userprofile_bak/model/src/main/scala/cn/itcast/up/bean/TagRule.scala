package cn.itcast.up.bean

/**
  * 5级标签规则封装
  * @param id
  * @param rule
  */
case class TagRule (
                   id: String,
                   rule: String
                   )
