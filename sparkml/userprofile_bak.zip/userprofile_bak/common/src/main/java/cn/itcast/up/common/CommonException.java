package cn.itcast.up.common;

public class CommonException extends RuntimeException {
}
